import { NextResponse } from "next/server";
import { isSupabaseConfigured } from "@/lib/supabase/config";
import { getVerifiedUser } from "@/lib/supabase/authorization";
import { createClient } from "@/lib/supabase/server";

const uuidPattern = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;

export async function POST(request: Request) {
  if (!isSupabaseConfigured()) return NextResponse.json({ error: "Blocking is not configured." }, { status: 503 });
  let body: unknown;
  try {
    body = await request.json();
  } catch {
    return NextResponse.json({ error: "Request body must be valid JSON." }, { status: 400 });
  }
  if (typeof body !== "object" || body === null || !("userId" in body) || typeof body.userId !== "string" || !uuidPattern.test(body.userId)) {
    return NextResponse.json({ error: "Choose a valid member to block." }, { status: 400 });
  }

  const supabase = await createClient();
  const user = await getVerifiedUser(supabase);
  if (!user) return NextResponse.json({ error: "Sign in with a verified account to block members." }, { status: 401 });
  if (body.userId === user.id) return NextResponse.json({ error: "You cannot block your own account." }, { status: 400 });

  const { error } = await supabase.from("ll_blocks").upsert(
    { blocker_id: user.id, blocked_user_id: body.userId },
    { onConflict: "blocker_id,blocked_user_id", ignoreDuplicates: true },
  );
  if (error) return NextResponse.json({ error: "Member could not be blocked." }, { status: 503 });
  return NextResponse.json({ blocked: true });
}

export async function DELETE(request: Request) {
  if (!isSupabaseConfigured()) return NextResponse.json({ error: "Blocking is not configured." }, { status: 503 });
  let body: unknown;
  try {
    body = await request.json();
  } catch {
    return NextResponse.json({ error: "Request body must be valid JSON." }, { status: 400 });
  }
  if (typeof body !== "object" || body === null || !("userId" in body) || typeof body.userId !== "string" || !uuidPattern.test(body.userId)) {
    return NextResponse.json({ error: "Choose a valid member to unblock." }, { status: 400 });
  }

  const supabase = await createClient();
  const user = await getVerifiedUser(supabase);
  if (!user) return NextResponse.json({ error: "Sign in with a verified account to manage blocks." }, { status: 401 });
  const { error } = await supabase.from("ll_blocks").delete().eq("blocker_id", user.id).eq("blocked_user_id", body.userId);
  if (error) return NextResponse.json({ error: "Member could not be unblocked." }, { status: 503 });
  return NextResponse.json({ blocked: false });
}