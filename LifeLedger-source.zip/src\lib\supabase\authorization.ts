import type { User } from "@supabase/supabase-js";
import type { createClient } from "./server";

type ServerClient = Awaited<ReturnType<typeof createClient>>;

export async function getVerifiedUser(supabase: ServerClient): Promise<User | null> {
  const { data, error } = await supabase.auth.getUser();
  if (error || !data.user) return null;
  if (!data.user.email_confirmed_at && !data.user.phone_confirmed_at) return null;
  return data.user;
}

export async function isLifeLedgerAdmin(supabase: ServerClient) {
  const { data, error } = await supabase.rpc("ll_is_admin");
  return !error && data === true;
}

export async function hasAal2(supabase: ServerClient) {
  const { data, error } = await supabase.auth.mfa.getAuthenticatorAssuranceLevel();
  return !error && data.currentLevel === "aal2";
}