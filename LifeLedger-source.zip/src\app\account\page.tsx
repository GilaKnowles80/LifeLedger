import Link from "next/link";
import { redirect } from "next/navigation";
import { ArrowLeft, ArrowRight, BadgeCheck, ShieldCheck, UserRound } from "lucide-react";
import { signOut } from "./actions";
import MfaEnrollment from "./security/mfa-enrollment";
import { createClient } from "@/lib/supabase/server";
import LifeLedgerMark from "@/components/lifeledger-mark";

export default async function AccountPage() {
  const supabase = await createClient();
  const { data: { user }, error } = await supabase.auth.getUser();
  if (error || !user) redirect("/register");

  const [profileResult, postResult, adResult, adminResult, factorsResult, assuranceResult] = await Promise.all([
    supabase.from("ll_profiles").select("username,display_name,avatar_url").eq("user_id", user.id).maybeSingle(),
    supabase.from("ll_posts").select("id", { count: "exact", head: true }).eq("author_id", user.id),
    supabase.from("ll_ads").select("id", { count: "exact", head: true }).eq("owner_id", user.id),
    supabase.rpc("ll_is_admin"),
    supabase.auth.mfa.listFactors(),
    supabase.auth.mfa.getAuthenticatorAssuranceLevel(),
  ]);

  const profile = profileResult.data;
  const displayName = profile?.display_name || user.email || user.phone || "LifeLedger member";
  const contact = user.email || user.phone || "Verified contact";
  const contactVerified = Boolean(user.email_confirmed_at || user.phone_confirmed_at);
  const verifiedFactors = factorsResult.data?.totp.filter((factor) => factor.status === "verified").length || 0;
  const isAdmin = !adminResult.error && adminResult.data === true;
  const isAal2 = assuranceResult.data?.currentLevel === "aal2";

  return (
    <main className="account-page">
      <header className="dashboard-header">
        <Link className="brand" href="/">
          <LifeLedgerMark />
          <span>Life<span className="brand-light">Ledger</span></span>
        </Link>
        <Link className="dashboard-back" href="/"><ArrowLeft size={15} /> Back to feed</Link>
      </header>
      <div className="dashboard-content">
        <div className="dashboard-title">
          <span className="eyebrow">YOUR LIFELEDGER</span>
          <h1>Your account</h1>
          <p>Your profile, activity, and account protection.</p>
        </div>
        <section className="account-identity dashboard-panel">
          <span className="account-avatar"><UserRound size={24} /></span>
          <div className="account-identity-copy">
            <h2>{displayName}</h2>
            <p>{profile?.username ? `@${profile.username}` : "Profile is being set up"}</p>
            <span className="verified-contact"><BadgeCheck size={15} /> {contact} {contactVerified ? "verified" : "not verified"}</span>
          </div>
          <form action={signOut}><button className="secondary-button" type="submit">Sign out</button></form>
        </section>
        <section className="account-stats">
          <article className="account-stat"><span className="eyebrow">YOUR POSTS</span><strong>{postResult.count ?? 0}</strong><span>including posts in review</span></article>
          <article className="account-stat"><span className="eyebrow">YOUR ADS</span><strong>{adResult.count ?? 0}</strong><span>paid ads and drafts</span></article>
          <article className="account-stat"><span className="eyebrow">ACCOUNT SECURITY</span><strong>{verifiedFactors ? "Protected" : "Improve it"}</strong><span>{verifiedFactors ? "Authenticator MFA enabled" : "Add authenticator MFA"}</span></article>
        </section>
        <section className="security-section dashboard-panel">
          <div className="dashboard-section-title"><div><span className="eyebrow">SIGN-IN PROTECTION</span><h2><ShieldCheck size={18} /> Authenticator verification</h2></div><span className={verifiedFactors ? "security-pill security-on" : "security-pill"}>{verifiedFactors ? "ENABLED" : "OPTIONAL"}</span></div>
          <p>Use an authenticator app for a second sign-in check. LifeLedger requires this extra verification for administrator actions.</p>
          <MfaEnrollment verified={verifiedFactors > 0} aal2={isAal2} />
        </section>
        {isAdmin && (
          <Link className="admin-dashboard-link dashboard-panel" href={isAal2 ? "/admin" : "/account/security?required=mfa"}>
            <span><span className="eyebrow">ADMINISTRATION</span><strong>LifeLedger admin dashboard</strong><small>{isAal2 ? "Review member posts, reports, and ads" : "Complete authenticator verification to continue"}</small></span>
            <ArrowRight size={18} />
          </Link>
        )}
        {!profileResult.data && <p className="account-setup-note">Profile data is unavailable until the LifeLedger database migration is applied.</p>}
      </div>
    </main>
  );
}