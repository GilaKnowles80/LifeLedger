import { NextResponse } from "next/server";
import { isSupabaseConfigured } from "@/lib/supabase/config";
import { getVerifiedUser } from "@/lib/supabase/authorization";
import { createClient } from "@/lib/supabase/server";

function jsonError(message: string, status: number) {
  return NextResponse.json({ error: message }, { status, headers: { "Cache-Control": "no-store" } });
}

export async function GET() {
  if (!isSupabaseConfigured()) return jsonError("Community data is not configured.", 503);
  const supabase = await createClient();
  const { data, error } = await supabase.rpc("ll_get_feed");
  if (error) return jsonError("The community feed is temporarily unavailable.", 503);
  return NextResponse.json({ posts: data || [] }, { headers: { "Cache-Control": "no-store" } });
}

export async function POST(request: Request) {
  if (!isSupabaseConfigured()) return jsonError("Community posting is not configured.", 503);
  let body: unknown;
  try {
    body = await request.json();
  } catch {
    return jsonError("Request body must be valid JSON.", 400);
  }
  if (typeof body !== "object" || body === null || !("body" in body) || typeof body.body !== "string") {
    return jsonError("Post text is required.", 400);
  }
  const text = body.body.trim();
  if (text.length < 1 || text.length > 5000) return jsonError("Posts must be 1 to 5000 characters.", 400);

  const supabase = await createClient();
  const user = await getVerifiedUser(supabase);
  if (!user) return jsonError("Verify your email or mobile number before posting.", 401);

  const { data, error } = await supabase
    .from("ll_posts")
    .insert({ author_id: user.id, body: text })
    .select("id,status")
    .single();
  if (error) {
    return jsonError(error.code === "P0001" ? "Posting rate limit reached. Please try again later." : "Post could not be submitted.", error.code === "P0001" ? 429 : 503);
  }
  return NextResponse.json({ id: data.id, status: data.status }, { status: 201, headers: { "Cache-Control": "no-store" } });
}