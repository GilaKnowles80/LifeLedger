"use server";

import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { createClient } from "@/lib/supabase/server";
import { getVerifiedUser, hasAal2, isLifeLedgerAdmin } from "@/lib/supabase/authorization";

const entityTypes = ["post", "comment", "advertisement", "report"] as const;
const decisions = ["approve", "reject", "remove", "resolve", "dismiss"] as const;

export async function moderateContent(formData: FormData) {
  const entityType = String(formData.get("entityType") || "");
  const entityId = String(formData.get("entityId") || "");
  const decision = String(formData.get("decision") || "");
  const moderationNote = String(formData.get("moderationNote") || "").trim().slice(0, 1000);

  if (!entityTypes.includes(entityType as (typeof entityTypes)[number]) || !decisions.includes(decision as (typeof decisions)[number]) || !entityId) {
    redirect("/admin?error=invalid");
  }

  const supabase = await createClient();
  const user = await getVerifiedUser(supabase);
  if (!user) redirect("/register");
  if (!(await isLifeLedgerAdmin(supabase))) redirect("/account?error=admin");
  if (!(await hasAal2(supabase))) redirect("/account/security?required=mfa");

  const { error } = await supabase.rpc("ll_moderate_content", {
    entity_type: entityType,
    entity_id: entityId,
    decision,
    moderation_note: moderationNote || null,
  });
  if (error) redirect("/admin?error=moderation");

  revalidatePath("/admin");
  revalidatePath("/");
  redirect("/admin?notice=reviewed");
}