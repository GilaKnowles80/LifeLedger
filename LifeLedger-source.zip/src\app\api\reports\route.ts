import { NextResponse } from "next/server";
import { isSupabaseConfigured } from "@/lib/supabase/config";
import { getVerifiedUser } from "@/lib/supabase/authorization";
import { createClient } from "@/lib/supabase/server";

const entityTypes = ["post", "comment", "profile", "advertisement"];
const reasons = ["spam", "harassment", "threats", "hate", "fraud", "sexual_content", "violence", "self_harm", "impersonation", "other"];

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}

export async function POST(request: Request) {
  if (!isSupabaseConfigured()) return NextResponse.json({ error: "Reporting is not configured." }, { status: 503 });
  let body: unknown;
  try {
    body = await request.json();
  } catch {
    return NextResponse.json({ error: "Request body must be valid JSON." }, { status: 400 });
  }
  if (!isRecord(body) || typeof body.entityType !== "string" || !entityTypes.includes(body.entityType) || typeof body.entityId !== "string" || typeof body.reason !== "string" || !reasons.includes(body.reason)) {
    return NextResponse.json({ error: "Choose a valid item and report reason." }, { status: 400 });
  }
  const details = typeof body.details === "string" ? body.details.trim() : "";
  if (details.length > 1000) return NextResponse.json({ error: "Report details are limited to 1000 characters." }, { status: 400 });

  const supabase = await createClient();
  const user = await getVerifiedUser(supabase);
  if (!user) return NextResponse.json({ error: "Verify your account before submitting a report." }, { status: 401 });

  const { data, error } = await supabase
    .from("ll_reports")
    .insert({ reporter_id: user.id, entity_type: body.entityType, entity_id: body.entityId, reason: body.reason, details })
    .select("id")
    .single();
  if (error) return NextResponse.json({ error: error.code === "P0001" ? "Report rate limit reached." : "Report could not be submitted." }, { status: error.code === "P0001" ? 429 : 503 });
  return NextResponse.json({ id: data.id, status: "open" }, { status: 201 });
}