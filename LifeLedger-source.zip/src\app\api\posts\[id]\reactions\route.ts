import { NextResponse } from "next/server";
import { isSupabaseConfigured } from "@/lib/supabase/config";
import { getVerifiedUser } from "@/lib/supabase/authorization";
import { createClient } from "@/lib/supabase/server";

type RouteContext = { params: Promise<{ id: string }> };
const uuidPattern = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;

async function requestContext(context: RouteContext) {
  if (!isSupabaseConfigured()) return { response: NextResponse.json({ error: "Reactions are not configured." }, { status: 503 }) };
  const { id: postId } = await context.params;
  if (!uuidPattern.test(postId)) return { response: NextResponse.json({ error: "Post was not found." }, { status: 404 }) };
  const supabase = await createClient();
  const user = await getVerifiedUser(supabase);
  if (!user) return { response: NextResponse.json({ error: "Sign in with a verified account to appreciate posts." }, { status: 401 }) };
  return { postId, supabase, user };
}

export async function POST(_request: Request, context: RouteContext) {
  const result = await requestContext(context);
  if ("response" in result) return result.response;
  const { error } = await result.supabase
    .from("ll_reactions")
    .upsert({ post_id: result.postId, user_id: result.user.id }, { onConflict: "post_id,user_id", ignoreDuplicates: true });
  if (error) return NextResponse.json({ error: "Reaction could not be saved." }, { status: 503 });
  return NextResponse.json({ appreciated: true });
}

export async function DELETE(_request: Request, context: RouteContext) {
  const result = await requestContext(context);
  if ("response" in result) return result.response;
  const { error } = await result.supabase
    .from("ll_reactions")
    .delete()
    .eq("post_id", result.postId)
    .eq("user_id", result.user.id);
  if (error) return NextResponse.json({ error: "Reaction could not be removed." }, { status: 503 });
  return NextResponse.json({ appreciated: false });
}