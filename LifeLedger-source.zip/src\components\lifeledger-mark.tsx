import Image from "next/image";

export default function LifeLedgerMark() {
  return (
    <Image
      className="brand-mark"
      src="/lifeledger-mark.svg"
      alt=""
      aria-hidden="true"
      width={48}
      height={36}
      priority
    />
  );
}