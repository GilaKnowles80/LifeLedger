"use client";

import Image from "next/image";
import { Check, KeyRound, LoaderCircle } from "lucide-react";
import { useState } from "react";
import { createClient } from "@/lib/supabase/client";

type MfaEnrollmentProps = { verified: boolean; aal2: boolean };

export default function MfaEnrollment({ verified, aal2 }: MfaEnrollmentProps) {
  const [factorId, setFactorId] = useState("");
  const [qrCode, setQrCode] = useState("");
  const [code, setCode] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [message, setMessage] = useState("");

  async function beginEnrollment() {
    setBusy(true);
    setError("");
    try {
      const supabase = createClient();
      const { data, error: enrollError } = await supabase.auth.mfa.enroll({
        factorType: "totp",
        friendlyName: "LifeLedger authenticator",
      });
      if (enrollError) throw enrollError;
      setFactorId(data.id);
      setQrCode(data.totp.qr_code);
      setMessage("Scan this QR code in your authenticator app, then enter its current code.");
    } catch (enrollError) {
      setError(enrollError instanceof Error ? enrollError.message : "Could not start authenticator setup.");
    } finally {
      setBusy(false);
    }
  }

  async function confirmEnrollment() {
    setBusy(true);
    setError("");
    try {
      const supabase = createClient();
      const challenge = await supabase.auth.mfa.challenge({ factorId });
      if (challenge.error) throw challenge.error;
      const verification = await supabase.auth.mfa.verify({
        factorId,
        challengeId: challenge.data.id,
        code: code.trim(),
      });
      if (verification.error) throw verification.error;
      setMessage("Authenticator verification is enabled.");
      setFactorId("");
      setQrCode("");
      window.location.reload();
    } catch (verificationError) {
      setError(verificationError instanceof Error ? verificationError.message : "That authenticator code was not accepted.");
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="mfa-manager">
      {verified ? (
        <div className="mfa-status"><Check size={16} /> {aal2 ? "Authenticator confirmed for this session." : "Authenticator is enrolled."}</div>
      ) : factorId ? (
        <div className="mfa-enrollment-flow">
          <Image className="mfa-qr" src={`data:image/svg+xml;utf8,${encodeURIComponent(qrCode)}`} alt="Authenticator setup QR code" width={220} height={220} unoptimized />
          <label htmlFor="totp-code">Authenticator code<input id="totp-code" inputMode="numeric" autoComplete="one-time-code" pattern="[0-9]{6}" maxLength={6} value={code} onChange={(event) => setCode(event.target.value.replace(/\D/g, "").slice(0, 6))} placeholder="6-digit code" /></label>
          <button className="post-button" type="button" disabled={busy || code.length !== 6} onClick={confirmEnrollment}>{busy ? <LoaderCircle size={15} /> : <Check size={15} />} Verify and enable</button>
        </div>
      ) : (
        <button className="secondary-button" type="button" disabled={busy} onClick={beginEnrollment}>{busy ? <LoaderCircle size={15} /> : <KeyRound size={15} />} Set up authenticator</button>
      )}
      {message && <p className="mfa-message" role="status">{message}</p>}
      {error && <p className="mfa-error" role="alert">{error}</p>}
    </div>
  );
}