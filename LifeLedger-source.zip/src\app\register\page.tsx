"use client";

import Link from "next/link";
import { Turnstile } from "@marsidev/react-turnstile";
import { ArrowLeft, ArrowRight, Mail, Phone, ShieldCheck } from "lucide-react";
import { FormEvent, useState } from "react";
import { useRouter } from "next/navigation";
import { isSupabaseConfigured } from "@/lib/supabase/config";
import { createClient } from "@/lib/supabase/client";
import LifeLedgerMark from "@/components/lifeledger-mark";

type SignInMethod = "email" | "phone";

export default function RegisterPage() {
  const router = useRouter();
  const [method, setMethod] = useState<SignInMethod>("email");
  const [contact, setContact] = useState("");
  const [otp, setOtp] = useState("");
  const [captchaToken, setCaptchaToken] = useState("");
  const [challengeSent, setChallengeSent] = useState(false);
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState("");
  const [error, setError] = useState("");

  const siteKey = process.env.NEXT_PUBLIC_TURNSTILE_SITE_KEY || "";
  const productionCaptchaReady = process.env.NODE_ENV !== "production" || Boolean(siteKey);
  const supabaseReady = isSupabaseConfigured();

  function chooseMethod(nextMethod: SignInMethod) {
    setMethod(nextMethod);
    setContact("");
    setOtp("");
    setCaptchaToken("");
    setChallengeSent(false);
    setMessage("");
    setError("");
  }

  async function requestSignIn(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setBusy(true);
    setError("");
    setMessage("");

    if (!supabaseReady) {
      setError("Account security is not configured yet. Please try again later.");
      setBusy(false);
      return;
    }
    if (!productionCaptchaReady || (siteKey && !captchaToken)) {
      setError("Complete the bot check before requesting a sign-in code.");
      setBusy(false);
      return;
    }
    if (method === "phone" && !/^\+[1-9]\d{6,14}$/.test(contact.trim())) {
      setError("Enter your mobile number in international format, for example +14155550123.");
      setBusy(false);
      return;
    }

    try {
      const supabase = createClient();
      const options = {
        shouldCreateUser: true,
        ...(captchaToken ? { captchaToken } : {}),
      };

      if (method === "email") {
        const { error: authError } = await supabase.auth.signInWithOtp({
          email: contact.trim().toLowerCase(),
          options: {
            ...options,
            emailRedirectTo: `${window.location.origin}/auth/callback?next=%2Faccount`,
          },
        });
        if (authError) throw authError;
        setMessage("We sent a single-use sign-in link to your email. Check that it came from your configured LifeLedger domain.");
      } else {
        const { error: authError } = await supabase.auth.signInWithOtp({
          phone: contact.trim(),
          options,
        });
        if (authError) throw authError;
        setChallengeSent(true);
        setMessage("Enter the short-lived code sent to your mobile number. Never share it with anyone.");
      }
    } catch (authError) {
      setError(authError instanceof Error ? authError.message : "Could not send a verification challenge.");
      setCaptchaToken("");
    } finally {
      setBusy(false);
    }
  }

  async function verifyPhone(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setBusy(true);
    setError("");
    try {
      const supabase = createClient();
      const { error: authError } = await supabase.auth.verifyOtp({
        phone: contact.trim(),
        token: otp.trim(),
        type: "sms",
      });
      if (authError) throw authError;
      router.replace("/account");
    } catch (authError) {
      setError(authError instanceof Error ? authError.message : "That code could not be verified.");
    } finally {
      setBusy(false);
    }
  }

  const activeSubmit = method === "phone" && challengeSent ? verifyPhone : requestSignIn;

  return (
    <main className="payment-result-page login-page">
      <Link className="brand" href="/">
        <LifeLedgerMark />
        <span>Life<span className="brand-light">Ledger</span></span>
      </Link>
      <section className="payment-result-panel login-panel auth-panel">
        <span className="payment-result-icon result-paid"><ShieldCheck size={22} /></span>
        <span className="eyebrow">SECURE LIFELEDGER ACCOUNT</span>
        <h1>Sign in or join.</h1>
        <p>Verify your email or mobile number each time. LifeLedger will never ask you to share a sign-in code.</p>

        {!supabaseReady ? (
          <div className="login-config-note">Supabase Auth is not configured. Add the project URL and publishable key to the deployment environment.</div>
        ) : !productionCaptchaReady ? (
          <div className="login-config-note">Turnstile is required for production sign-in. Configure `NEXT_PUBLIC_TURNSTILE_SITE_KEY` and enable CAPTCHA in Supabase Auth.</div>
        ) : (
          <>
            <div className="auth-method-switch" role="group" aria-label="Choose sign-in method">
              <button type="button" className={method === "email" ? "auth-method active" : "auth-method"} onClick={() => chooseMethod("email")}><Mail size={15} /> Email</button>
              <button type="button" className={method === "phone" ? "auth-method active" : "auth-method"} onClick={() => chooseMethod("phone")}><Phone size={15} /> Mobile</button>
            </div>
            <form className="login-form" onSubmit={activeSubmit}>
              {!challengeSent && (
                <>
                  <label htmlFor="account-contact">{method === "email" ? "Email address" : "Mobile number"}</label>
                  <input
                    id="account-contact"
                    type={method === "email" ? "email" : "tel"}
                    autoComplete={method === "email" ? "email" : "tel"}
                    inputMode={method === "phone" ? "tel" : "email"}
                    required
                    value={contact}
                    onChange={(event) => setContact(event.target.value)}
                    placeholder={method === "email" ? "you@example.com" : "+14155550123"}
                  />
                  {siteKey && <Turnstile siteKey={siteKey} onSuccess={setCaptchaToken} onExpire={() => setCaptchaToken("")} />}
                </>
              )}
              {method === "phone" && challengeSent && (
                <>
                  <label htmlFor="phone-otp">Verification code</label>
                  <input id="phone-otp" inputMode="numeric" autoComplete="one-time-code" pattern="[0-9]{6}" minLength={6} maxLength={6} required value={otp} onChange={(event) => setOtp(event.target.value.replace(/\D/g, "").slice(0, 6))} placeholder="6-digit code" />
                </>
              )}
              {error && <p className="auth-message auth-error" role="alert">{error}</p>}
              {message && <p className="auth-message" role="status">{message}</p>}
              <button className="ad-submit-button" type="submit" disabled={busy || (Boolean(siteKey) && !captchaToken && !challengeSent)}>
                {busy ? "Verifying..." : method === "phone" && challengeSent ? <>Verify and continue <ArrowRight size={16} /></> : method === "phone" ? <>Send mobile code <ArrowRight size={16} /></> : <>Email me a sign-in link <ArrowRight size={16} /></>}
              </button>
              {method === "phone" && challengeSent && <button className="auth-resend" type="button" onClick={() => { setChallengeSent(false); setOtp(""); setMessage(""); setCaptchaToken(""); }}>Use a different number or request a new code</button>}
            </form>
          </>
        )}
        <Link className="payment-return-link" href="/"><ArrowLeft size={15} /> Back to LifeLedger</Link>
      </section>
    </main>
  );
}