# Proprietary License

Copyright (c) 2026 [Gila Arayan Cain]. All rights reserved.

This software, including its source code, design, text, graphics, and other associated materials (the "Work"), is proprietary and confidential to the copyright holder.

No permission or license is granted to any person to copy, reproduce, publish, distribute, sublicense, modify, adapt, create derivative works from, publicly display, publicly perform, or commercially exploit the Work, in whole or in part, without the copyright holder's prior written permission.

Access to or possession of a copy of the Work does not transfer ownership or grant any rights to use it beyond viewing it for evaluation. Any unauthorized use, copying, modification, or distribution is prohibited to the fullest extent permitted by applicable law.

THE WORK IS PROVIDED "AS IS", WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, TO THE FULLEST EXTENT PERMITTED BY APPLICABLE LAW.

Replace `[Gila Arayan Cain]` with the legal name of the person or entity that owns LifeLedger before distributing the project. This notice does not replace any rights or protections that apply automatically under copyright law.
